# دليل بناء ملف APK - تطبيق المحلل المالي الذكي

## مقدمة

هذا الدليل يشرح كيفية بناء ملف APK (Android Package) من مشروع React Native/Expo الخاص بك. يمكنك اختيار بين عدة طرق حسب احتياجاتك.

## الطريقة 1: استخدام Expo Build (الأسهل - موصى به)

هذه الطريقة تستخدم خدمة Expo المجانية لبناء APK بدون الحاجة لتثبيت Android SDK محلياً.

### الخطوات:

#### 1. تثبيت Expo CLI
```bash
npm install -g expo-cli
# أو
yarn global add expo-cli
```

#### 2. تسجيل الدخول إلى Expo
```bash
expo login
# أدخل بيانات حسابك على Expo (أو أنشئ حساب جديد)
```

#### 3. بناء APK
```bash
cd bank_sms_analyzer
expo build:android --type apk
```

#### 4. الانتظار والتنزيل
- سيطلب منك تحديد نوع التوقيع (Keystore)
- اختر "Let Expo handle the process" للمرة الأولى
- سيبدأ البناء ويستغرق 10-15 دقيقة
- ستحصل على رابط لتنزيل APK عند الانتهاء

## الطريقة 2: بناء محلي باستخدام EAS CLI (الأفضل للإنتاج)

### المتطلبات:
- Node.js 16+
- Java Development Kit (JDK) 11+
- Android SDK

### الخطوات:

#### 1. تثبيت EAS CLI
```bash
npm install -g eas-cli
```

#### 2. تسجيل الدخول
```bash
eas login
```

#### 3. إعداد المشروع
```bash
cd bank_sms_analyzer
eas build:configure
```

#### 4. بناء APK
```bash
# للتطوير (Debug)
eas build --platform android --profile preview

# للإصدار (Release)
eas build --platform android --profile production
```

## الطريقة 3: بناء محلي باستخدام Gradle (للمتقدمين)

### المتطلبات:
- Java Development Kit (JDK) 11 أو أحدث
- Android SDK مثبت بالكامل
- Gradle مثبت

### الخطوات:

#### 1. إعداد البيئة

**على Windows:**
```powershell
# تعيين متغيرات البيئة
$env:JAVA_HOME = "C:\Program Files\Java\jdk-11.0.x"
$env:ANDROID_SDK_ROOT = "C:\Users\YourUsername\AppData\Local\Android\Sdk"
$env:ANDROID_HOME = $env:ANDROID_SDK_ROOT
```

**على macOS/Linux:**
```bash
export JAVA_HOME=$(/usr/libexec/java_home -v 11)
export ANDROID_SDK_ROOT=$HOME/Library/Android/sdk
export ANDROID_HOME=$ANDROID_SDK_ROOT
export PATH=$PATH:$ANDROID_SDK_ROOT/platform-tools:$ANDROID_SDK_ROOT/tools
```

#### 2. بناء APK
```bash
cd bank_sms_analyzer/android

# للتطوير (Debug)
./gradlew assembleDebug

# للإصدار (Release)
./gradlew assembleRelease
```

#### 3. موقع ملف APK
- **Debug**: `app/build/outputs/apk/debug/app-debug.apk`
- **Release**: `app/build/outputs/apk/release/app-release.apk`

## الطريقة 4: استخدام Expo Go للاختبار السريع

إذا كنت تريد اختبار التطبيق بسرعة بدون بناء APK:

```bash
cd bank_sms_analyzer

# بدء خادم التطوير
expo start

# ستظهر رموز QR - امسحها بتطبيق Expo Go على جهازك
```

## مقارنة الطرق

| الطريقة | السهولة | السرعة | المتطلبات | النتيجة |
|--------|--------|--------|----------|---------|
| Expo Build | سهلة جداً | 10-15 دقيقة | حساب Expo | APK جاهز |
| EAS CLI | سهلة | 5-10 دقيقة | حساب Expo + CLI | APK جاهز |
| Gradle محلي | متوسطة | 5-10 دقيقة | JDK + Android SDK | APK جاهز |
| Expo Go | سهلة جداً | فوري | لا شيء | اختبار فقط |

## تثبيت APK على جهازك

### عبر USB:
```bash
adb install path/to/app-debug.apk
```

### نقل يدوي:
1. انسخ ملف APK إلى جهازك
2. افتح مدير الملفات
3. انقر على APK لتثبيته

## استكشاف الأخطاء

### خطأ: "Java not found"
```bash
# تحقق من تثبيت Java
java -version

# إذا لم يكن مثبتاً، ثبته من:
# https://www.oracle.com/java/technologies/downloads/
```

### خطأ: "Android SDK not found"
```bash
# تأكد من تعيين متغيرات البيئة
echo $ANDROID_SDK_ROOT  # على macOS/Linux
echo %ANDROID_SDK_ROOT%  # على Windows
```

### خطأ: "Gradle build failed"
```bash
# نظف ملفات البناء السابقة
cd android
./gradlew clean
./gradlew assembleDebug
```

## نصائح مهمة

1. **للإصدار الأول**: استخدم Expo Build (الطريقة 1) - الأسهل
2. **للتطوير المستمر**: استخدم Expo Go للاختبار السريع
3. **للإنتاج**: استخدم EAS CLI مع profile production
4. **للمتقدمين**: استخدم Gradle محلي للتحكم الكامل

## الملفات المهمة

- `app.config.ts` - إعدادات التطبيق والصلاحيات
- `android/app/build.gradle` - إعدادات Gradle
- `android/app/src/main/AndroidManifest.xml` - بيانات التطبيق

## المراجع

- [Expo Build Documentation](https://docs.expo.dev/build/setup/)
- [EAS CLI Documentation](https://docs.expo.dev/eas-cli/introduction/)
- [React Native Build Guide](https://reactnative.dev/docs/android-setup)

---

**ملاحظة**: تأكد من أن جميع الملفات محفوظة وأن لا توجد أخطاء في الكود قبل البدء في البناء.
