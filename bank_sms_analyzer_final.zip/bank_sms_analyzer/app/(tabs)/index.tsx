import React, { useEffect, useState } from 'react';
import {
  ScrollView,
  Text,
  View,
  FlatList,
  TouchableOpacity,
  RefreshControl,
  Alert,
  StyleSheet,
} from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { databaseService, Transaction } from '@/lib/services/database';
import { smsListenerService } from '@/lib/services/sms-listener';

export default function HomeScreen() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [totalSpent, setTotalSpent] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const [isListening, setIsListening] = useState(false);

  useEffect(() => {
    initializeApp();
  }, []);

  const initializeApp = async () => {
    try {
      // Initialize database
      await databaseService.initDatabase();

      // Load transactions
      await loadTransactions();

      // Start SMS listener
      await startSmsListener();
    } catch (error) {
      console.error('Error initializing app:', error);
      Alert.alert('خطأ', 'حدث خطأ في تهيئة التطبيق');
    }
  };

  const loadTransactions = async () => {
    try {
      const txs = await databaseService.getTransactions();
      const total = await databaseService.getTotalSpent();

      setTransactions(txs);
      setTotalSpent(total || 0);
    } catch (error) {
      console.error('Error loading transactions:', error);
      Alert.alert('خطأ', 'حدث خطأ في تحميل البيانات');
    }
  };

  const startSmsListener = async () => {
    try {
      await smsListenerService.startListening();
      setIsListening(true);

      // Subscribe to SMS events
      const unsubscribe = smsListenerService.onSmsReceived(
        (sender: string, message: string) => {
          console.log(`New SMS received from ${sender}`);
          loadTransactions();
        }
      );

      return () => {
        unsubscribe();
        smsListenerService.stopListening();
      };
    } catch (error) {
      console.error('Error starting SMS listener:', error);
      Alert.alert(
        'تنبيه',
        'لم يتمكن التطبيق من الوصول إلى الرسائل. تأكد من منح الصلاحيات.'
      );
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      await loadTransactions();
    } catch (error) {
      console.error('Error refreshing:', error);
    } finally {
      setRefreshing(false);
    }
  };

  const handleDeleteTransaction = async (id: number | undefined) => {
    if (!id) return;

    Alert.alert('حذف العملية', 'هل تريد حذف هذه العملية؟', [
      {
        text: 'إلغاء',
        onPress: () => {},
        style: 'cancel',
      },
      {
        text: 'حذف',
        onPress: async () => {
          try {
            await databaseService.deleteTransaction(id);
            await loadTransactions();
            Alert.alert('نجح', 'تم حذف العملية بنجاح');
          } catch (error) {
            Alert.alert('خطأ', 'حدث خطأ في حذف العملية');
          }
        },
        style: 'destructive',
      },
    ]);
  };

  const getCategoryColor = (category: string): string => {
    const colors: { [key: string]: string } = {
      تسوق: '#FF6B6B',
      حوالات: '#4ECDC4',
      كاش: '#45B7D1',
      مطاعم: '#FFA07A',
      نقل: '#98D8C8',
      اتصالات: '#F7DC6F',
      إيداع: '#52C77A',
    };
    return colors[category] || '#95A5A6';
  };

  const renderTransactionItem = ({ item }: { item: Transaction }) => (
    <TouchableOpacity
      style={styles.transactionCard}
      onLongPress={() => handleDeleteTransaction(item.id)}
    >
      <View style={styles.cardHeader}>
        <View
          style={[
            styles.categoryBadge,
            { backgroundColor: getCategoryColor(item.category) },
          ]}
        >
          <Text style={styles.categoryText}>{item.category}</Text>
        </View>
        <Text style={styles.amountText}>{item.amount.toFixed(2)} ر.س</Text>
      </View>

      <Text style={styles.merchantText}>{item.merchant}</Text>

      <View style={styles.cardFooter}>
        <Text style={styles.dateTimeText}>
          {item.date} | {item.time}
        </Text>
        <Text style={styles.sourceText}>{item.source}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <ScreenContainer className="bg-[#ECE5DD]">
      {/* Header with total spent */}
      <View style={styles.header}>
        <Text style={styles.headerLabel}>إجمالي المصروفات</Text>
        <Text style={styles.totalAmount}>
          {totalSpent.toFixed(2)} ر.س
        </Text>
        <View style={styles.statusBar}>
          <View
            style={[
              styles.statusDot,
              { backgroundColor: isListening ? '#52C77A' : '#E74C3C' },
            ]}
          />
          <Text style={styles.statusText}>
            {isListening ? 'مراقبة نشطة' : 'مراقبة معطلة'}
          </Text>
        </View>
      </View>

      {/* Transactions list */}
      {transactions.length > 0 ? (
        <FlatList
          data={transactions}
          renderItem={renderTransactionItem}
          keyExtractor={(item) => item.id?.toString() || Math.random().toString()}
          contentContainerStyle={styles.listContent}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
        />
      ) : (
        <View style={styles.emptyState}>
          <Text style={styles.emptyStateTitle}>لا توجد عمليات</Text>
          <Text style={styles.emptyStateText}>
            سيتم عرض العمليات المالية هنا عند استقبال رسائل بنكية
          </Text>
        </View>
      )}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    backgroundColor: '#075E54',
    paddingVertical: 20,
    paddingHorizontal: 16,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    marginBottom: 16,
  },
  headerLabel: {
    color: '#FFFFFF',
    fontSize: 14,
    opacity: 0.8,
    marginBottom: 8,
    textAlign: 'center',
  },
  totalAmount: {
    color: '#FFFFFF',
    fontSize: 32,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 12,
  },
  statusBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 8,
  },
  statusText: {
    color: '#FFFFFF',
    fontSize: 12,
  },
  listContent: {
    paddingHorizontal: 12,
    paddingBottom: 20,
  },
  transactionCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 12,
    marginVertical: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  categoryBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
  },
  categoryText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '600',
  },
  amountText: {
    color: '#E74C3C',
    fontSize: 16,
    fontWeight: 'bold',
  },
  merchantText: {
    color: '#2C3E50',
    fontSize: 15,
    fontWeight: '500',
    marginBottom: 8,
  },
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  dateTimeText: {
    color: '#95A5A6',
    fontSize: 11,
  },
  sourceText: {
    color: '#7F8C8D',
    fontSize: 10,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  emptyStateTitle: {
    color: '#2C3E50',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
    textAlign: 'center',
  },
  emptyStateText: {
    color: '#7F8C8D',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
});
