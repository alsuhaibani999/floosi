import { NativeModules, NativeEventEmitter } from 'react-native';
import { databaseService } from './database';
import { smsAnalyzerService } from './sms-analyzer';

// For Android SMS listener
const SmsListener = NativeModules.SmsListener || {};

export type SmsCallback = (sender: string, message: string) => void;

class SmsListenerService {
  private listeners: SmsCallback[] = [];
  private isListening = false;

  /**
   * Start listening for incoming SMS messages
   */
  async startListening(): Promise<void> {
    if (this.isListening) {
      console.log('SMS listener already started');
      return;
    }

    try {
      // Request SMS permissions
      await this.requestSmsPermissions();

      // Set up native event listener if available
      if (SmsListener.startListener) {
        SmsListener.startListener();
      }

      // Set up event emitter for incoming SMS
      const eventEmitter = new NativeEventEmitter(SmsListener);
      eventEmitter.addListener('onSmsReceived', (event: any) => {
        this.handleIncomingSms(event.sender, event.message);
      });

      this.isListening = true;
      console.log('SMS listener started successfully');
    } catch (error) {
      console.error('Error starting SMS listener:', error);
      throw error;
    }
  }

  /**
   * Stop listening for incoming SMS messages
   */
  stopListening(): void {
    if (SmsListener.stopListener) {
      SmsListener.stopListener();
    }
    this.isListening = false;
    console.log('SMS listener stopped');
  }

  /**
   * Request SMS permissions from user
   */
  private async requestSmsPermissions(): Promise<void> {
    try {
      if (SmsListener.requestPermissions) {
        const granted = await SmsListener.requestPermissions();
        if (!granted) {
          throw new Error('SMS permissions not granted');
        }
      }
    } catch (error) {
      console.error('Error requesting SMS permissions:', error);
      throw error;
    }
  }

  /**
   * Handle incoming SMS message
   */
  private async handleIncomingSms(sender: string, message: string): Promise<void> {
    try {
      console.log(`Incoming SMS from ${sender}: ${message.substring(0, 50)}...`);

      // Check if message is from a bank
      if (!smsAnalyzerService.isBankMessage(message, sender)) {
        console.log('Message is not from a bank, skipping');
        return;
      }

      // Analyze SMS
      const analyzed = smsAnalyzerService.analyzeSms(message, sender);
      if (!analyzed || !analyzed.isValid) {
        console.log('Could not analyze SMS');
        return;
      }

      // Convert to transaction
      const transaction = smsAnalyzerService.convertToTransaction(
        analyzed,
        message,
        sender
      );

      // Save to database
      await databaseService.insertTransaction(transaction);
      console.log('Transaction saved:', transaction);

      // Notify listeners
      this.notifyListeners(sender, message);
    } catch (error) {
      console.error('Error handling incoming SMS:', error);
    }
  }

  /**
   * Register callback for SMS events
   */
  onSmsReceived(callback: SmsCallback): () => void {
    this.listeners.push(callback);

    // Return unsubscribe function
    return () => {
      this.listeners = this.listeners.filter((cb) => cb !== callback);
    };
  }

  /**
   * Notify all listeners
   */
  private notifyListeners(sender: string, message: string): void {
    this.listeners.forEach((callback) => {
      try {
        callback(sender, message);
      } catch (error) {
        console.error('Error in SMS listener callback:', error);
      }
    });
  }

  /**
   * Check if SMS listener is currently active
   */
  isActive(): boolean {
    return this.isListening;
  }
}

export const smsListenerService = new SmsListenerService();
