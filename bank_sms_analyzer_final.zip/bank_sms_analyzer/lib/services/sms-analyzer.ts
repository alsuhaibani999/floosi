import { Transaction } from './database';

export interface AnalyzedSMS {
  amount: number;
  merchant: string;
  category: string;
  isValid: boolean;
}

class SmsAnalyzerService {
  /**
   * Analyze SMS message and extract financial information
   */
  analyzeSms(message: string, sender: string): AnalyzedSMS | null {
    // Check if message contains financial information
    const amountMatch = this.extractAmount(message);
    if (!amountMatch) {
      return null;
    }

    const merchant = this.extractMerchant(message);
    const category = this.categorizeTransaction(message, merchant);

    return {
      amount: amountMatch,
      merchant,
      category,
      isValid: true,
    };
  }

  /**
   * Extract amount from SMS message
   * Supports: 100 SAR, 100ريال, 100 بـ, 100.50
   */
  private extractAmount(message: string): number | null {
    // Pattern to match amounts with various formats
    const patterns = [
      /(\d+(?:\.\d{1,2})?)\s*(?:SAR|ريال|بـ|ر\.س)/i,
      /(?:SAR|ريال|بـ|ر\.س)\s*(\d+(?:\.\d{1,2})?)/i,
      /المبلغ\s*[:=]?\s*(\d+(?:\.\d{1,2})?)/i,
      /الرصيد\s*[:=]?\s*(\d+(?:\.\d{1,2})?)/i,
      /(\d+(?:\.\d{1,2})?)\s*(?:ريال|SAR)/,
    ];

    for (const pattern of patterns) {
      const match = message.match(pattern);
      if (match) {
        const amount = parseFloat(match[1]);
        if (!isNaN(amount) && amount > 0) {
          return amount;
        }
      }
    }

    return null;
  }

  /**
   * Extract merchant/bank name from SMS message
   */
  private extractMerchant(message: string): string {
    // Common Saudi bank patterns
    const bankPatterns: { [key: string]: string[] } = {
      'البنك الأهلي': ['ahli', 'أهلي', 'NCB'],
      'الراجحي': ['rajhi', 'الراجحي', 'ARB'],
      'الإمارات': ['emirates', 'الإمارات', 'FAB'],
      'الرياض': ['riyad', 'الرياض', 'RB'],
      'سامبا': ['samba', 'سامبا', 'SABB'],
      'الجزيرة': ['jazira', 'الجزيرة', 'BJB'],
      'الاستثمار': ['investcorp', 'الاستثمار'],
      'البلاد': ['albilad', 'البلاد'],
      'الخليج': ['gulf', 'الخليج'],
      'الأول': ['awal', 'الأول'],
      'Dunkin': ['dunkin', 'دانكن'],
      'Barq': ['barq', 'بارق'],
      'Uber': ['uber', 'أوبر'],
      'Careem': ['careem', 'كريم'],
      'Zain': ['zain', 'زين'],
      'STC': ['stc', 'الاتصالات'],
      'Mobily': ['mobily', 'موبايلي'],
    };

    // Check for "من" pattern (from)
    const fromMatch = message.match(/من\s+([A-Z0-9\s\*]+|[أ-ي\s\*]+)/i);
    if (fromMatch) {
      return fromMatch[1].trim();
    }

    // Check for bank patterns
    for (const [bankName, keywords] of Object.entries(bankPatterns)) {
      for (const keyword of keywords) {
        if (message.toLowerCase().includes(keyword.toLowerCase())) {
          return bankName;
        }
      }
    }

    // Default to unknown
    return 'غير معروف';
  }

  /**
   * Categorize transaction based on message content
   */
  private categorizeTransaction(message: string, merchant: string): string {
    const lowerMessage = message.toLowerCase();
    const lowerMerchant = merchant.toLowerCase();

    // Transfer patterns
    if (lowerMessage.includes('حوالة') || lowerMessage.includes('transfer')) {
      return 'حوالات';
    }

    // Withdrawal patterns
    if (lowerMessage.includes('سحب') || lowerMessage.includes('withdrawal')) {
      return 'كاش';
    }

    // Deposit patterns
    if (lowerMessage.includes('إيداع') || lowerMessage.includes('deposit')) {
      return 'إيداع';
    }

    // Restaurant patterns
    if (
      lowerMerchant.includes('dunkin') ||
      lowerMerchant.includes('دانكن') ||
      lowerMessage.includes('مطعم') ||
      lowerMessage.includes('restaurant')
    ) {
      return 'مطاعم';
    }

    // Ride sharing
    if (
      lowerMerchant.includes('uber') ||
      lowerMerchant.includes('أوبر') ||
      lowerMerchant.includes('careem') ||
      lowerMerchant.includes('كريم')
    ) {
      return 'نقل';
    }

    // Telecom
    if (
      lowerMerchant.includes('zain') ||
      lowerMerchant.includes('زين') ||
      lowerMerchant.includes('stc') ||
      lowerMerchant.includes('الاتصالات') ||
      lowerMerchant.includes('mobily') ||
      lowerMerchant.includes('موبايلي')
    ) {
      return 'اتصالات';
    }

    // Default category
    return 'تسوق';
  }

  /**
   * Check if message is from a bank
   */
  isBankMessage(message: string, sender: string): boolean {
    const bankKeywords = [
      'بنك',
      'bank',
      'حسابك',
      'رصيدك',
      'عملية',
      'transaction',
      'مبلغ',
      'amount',
      'حوالة',
      'transfer',
      'سحب',
      'withdrawal',
      'إيداع',
      'deposit',
    ];

    const lowerMessage = message.toLowerCase();
    return bankKeywords.some((keyword) =>
      lowerMessage.includes(keyword.toLowerCase())
    );
  }

  /**
   * Convert analyzed SMS to transaction object
   */
  convertToTransaction(
    analyzed: AnalyzedSMS,
    message: string,
    sender: string
  ): Transaction {
    const now = new Date();
    const date = now.toISOString().split('T')[0]; // YYYY-MM-DD
    const time = now.toTimeString().split(' ')[0]; // HH:mm:ss

    return {
      amount: analyzed.amount,
      merchant: analyzed.merchant,
      category: analyzed.category,
      date,
      time,
      source: sender,
      rawText: message,
    };
  }
}

export const smsAnalyzerService = new SmsAnalyzerService();
