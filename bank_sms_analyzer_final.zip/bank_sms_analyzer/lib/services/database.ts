import SQLite from 'react-native-sqlite-storage';

SQLite.DEBUG(false);
SQLite.enablePromise(true);

export interface SQLiteDatabase {
  executeSql(sql: string, params?: any[]): Promise<any[]>;
  close(): Promise<void>;
}

export interface Transaction {
  id?: number;
  amount: number;
  merchant: string;
  category: string;
  date: string;
  time: string;
  source: string;
  rawText: string;
}

class DatabaseService {
  private db: SQLiteDatabase | null = null;

  async initDatabase(): Promise<void> {
    try {
      this.db = await SQLite.openDatabase({
        name: 'finance_manager.db',
        location: 'default',
      });

      await this.db.executeSql(
        `CREATE TABLE IF NOT EXISTS transactions(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          amount REAL NOT NULL,
          merchant TEXT NOT NULL,
          category TEXT NOT NULL,
          date TEXT NOT NULL,
          time TEXT NOT NULL,
          source TEXT NOT NULL,
          rawText TEXT NOT NULL,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`
      );

      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Error initializing database:', error);
      throw error;
    }
  }

  async insertTransaction(transaction: Transaction): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const result = await this.db.executeSql(
        `INSERT INTO transactions (amount, merchant, category, date, time, source, rawText)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          transaction.amount,
          transaction.merchant,
          transaction.category,
          transaction.date,
          transaction.time,
          transaction.source,
          transaction.rawText,
        ]
      );

      console.log('Transaction inserted:', result);
      return result[0].insertId;
    } catch (error) {
      console.error('Error inserting transaction:', error);
      throw error;
    }
  }

  async getTransactions(): Promise<Transaction[]> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const result = await this.db.executeSql(
        `SELECT * FROM transactions ORDER BY id DESC`
      );

      const transactions: Transaction[] = [];
      if (result[0].rows.length > 0) {
        for (let i = 0; i < result[0].rows.length; i++) {
          transactions.push(result[0].rows.item(i));
        }
      }

      return transactions;
    } catch (error) {
      console.error('Error fetching transactions:', error);
      throw error;
    }
  }

  async getTotalSpent(): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const result = await this.db.executeSql(
        `SELECT SUM(amount) as total FROM transactions`
      );

      if (result[0].rows.length > 0) {
        return result[0].rows.item(0).total || 0;
      }

      return 0;
    } catch (error) {
      console.error('Error calculating total spent:', error);
      throw error;
    }
  }

  async deleteTransaction(id: number): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      await this.db.executeSql(
        `DELETE FROM transactions WHERE id = ?`,
        [id]
      );

      console.log('Transaction deleted:', id);
    } catch (error) {
      console.error('Error deleting transaction:', error);
      throw error;
    }
  }

  async closeDatabase(): Promise<void> {
    if (this.db) {
      try {
        await this.db.close();
        this.db = null;
        console.log('Database closed');
      } catch (error) {
        console.error('Error closing database:', error);
      }
    }
  }
}

export const databaseService = new DatabaseService();
