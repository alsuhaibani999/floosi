declare module 'react-native-sqlite-storage' {
  export interface Database {
    executeSql(sql: string, params?: any[]): Promise<any[]>;
    close(): Promise<void>;
  }

  export interface DatabaseOptions {
    name: string;
    location?: string;
  }

  const SQLite: {
    DEBUG(enable: boolean): void;
    enablePromise(enable: boolean): void;
    openDatabase(options: DatabaseOptions): Promise<Database>;
  };

  export default SQLite;
}
