package com.banksmsanalyzer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.telephony.SmsMessage;
import android.util.Log;

import androidx.core.content.ContextCompat;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;

public class SmsListenerModule extends ReactContextBaseJavaModule {
  private static final String TAG = "SmsListenerModule";
  private static final String MODULE_NAME = "SmsListener";
  private SmsReceiver smsReceiver;
  private ReactApplicationContext reactContext;

  public SmsListenerModule(ReactApplicationContext context) {
    super(context);
    this.reactContext = context;
  }

  @Override
  public String getName() {
    return MODULE_NAME;
  }

  @ReactMethod
  public void startListener() {
    try {
      if (smsReceiver == null) {
        smsReceiver = new SmsReceiver(reactContext);
        IntentFilter filter = new IntentFilter("android.provider.Telephony.SMS_RECEIVED");
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
          ContextCompat.registerReceiver(
            reactContext,
            smsReceiver,
            filter,
            ContextCompat.RECEIVER_EXPORTED
          );
        } else {
          reactContext.registerReceiver(smsReceiver, filter);
        }
        
        Log.d(TAG, "SMS listener started");
      }
    } catch (Exception e) {
      Log.e(TAG, "Error starting SMS listener: " + e.getMessage());
    }
  }

  @ReactMethod
  public void stopListener() {
    try {
      if (smsReceiver != null) {
        reactContext.unregisterReceiver(smsReceiver);
        smsReceiver = null;
        Log.d(TAG, "SMS listener stopped");
      }
    } catch (Exception e) {
      Log.e(TAG, "Error stopping SMS listener: " + e.getMessage());
    }
  }

  @ReactMethod
  public void requestPermissions(Promise promise) {
    try {
      // Permissions are handled by the app's AndroidManifest.xml and runtime permissions
      promise.resolve(true);
    } catch (Exception e) {
      promise.reject("ERROR", e.getMessage());
    }
  }

  /**
   * Inner class to handle incoming SMS messages
   */
  public class SmsReceiver extends BroadcastReceiver {
    private ReactApplicationContext context;

    public SmsReceiver(ReactApplicationContext context) {
      this.context = context;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
      try {
        if (intent.getAction().equals("android.provider.Telephony.SMS_RECEIVED")) {
          Object[] pdus = (Object[]) intent.getExtras().get("pdus");
          String format = intent.getExtras().getString("format");

          if (pdus != null) {
            for (Object pdu : pdus) {
              SmsMessage smsMessage = SmsMessage.createFromPdu((byte[]) pdu, format);
              String sender = smsMessage.getOriginatingAddress();
              String messageBody = smsMessage.getMessageBody();

              Log.d(TAG, "SMS received from: " + sender);
              Log.d(TAG, "Message: " + messageBody);

              // Send event to React Native
              sendEvent(context, "onSmsReceived", sender, messageBody);
            }
          }
        }
      } catch (Exception e) {
        Log.e(TAG, "Error processing SMS: " + e.getMessage());
      }
    }

    private void sendEvent(Context context, String eventName, String sender, String message) {
      try {
        WritableMap params = Arguments.createMap();
        params.putString("sender", sender);
        params.putString("message", message);

        reactContext
          .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
          .emit(eventName, params);
      } catch (Exception e) {
        Log.e(TAG, "Error sending event: " + e.getMessage());
      }
    }
  }
}
