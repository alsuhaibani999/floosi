# تطبيق المحلل المالي الذكي - دليل الإعداد والبناء

## نظرة عامة

تطبيق أندرويد ذكي يعمل في الخلفية لمراقبة الرسائل النصية SMS الواردة من البنوك، وتحليلها فوراً لاستخراج المصروفات والايرادات. التطبيق يحفظ جميع البيانات محلياً على جهازك.

## المتطلبات

### متطلبات النظام
- **نظام التشغيل**: Windows 10+ أو macOS 10.15+ أو Linux
- **Node.js**: الإصدار 16.0 أو أحدث
- **Java Development Kit (JDK)**: الإصدار 11 أو أحدث
- **Android SDK**: API Level 24 (Android 7.0) أو أحدث
- **مساحة تخزين**: 5 GB على الأقل

### متطلبات الجهاز
- **جهاز أندرويد**: يعمل بنظام Android 7.0 أو أحدث
- **صلاحيات**: يجب منح التطبيق صلاحيات قراءة الرسائل (READ_SMS) واستقبالها (RECEIVE_SMS)

## خطوات الإعداد

### 1. تثبيت أدوات التطوير

#### على Windows:
```bash
# تثبيت Node.js من https://nodejs.org/
# تثبيت JDK من https://www.oracle.com/java/technologies/downloads/

# تثبيت Android Studio من https://developer.android.com/studio
# ثم تثبيت Android SDK من خلال Android Studio
```

#### على macOS:
```bash
# تثبيت Homebrew
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# تثبيت Node.js و Java
brew install node@18 openjdk@11

# تثبيت Android Studio
brew install --cask android-studio
```

#### على Linux (Ubuntu/Debian):
```bash
# تثبيت Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# تثبيت Java
sudo apt-get install -y openjdk-11-jdk

# تثبيت Android SDK
# يمكن تحميل Android Studio من https://developer.android.com/studio
```

### 2. إعداد متغيرات البيئة

#### على Windows (PowerShell):
```powershell
$env:JAVA_HOME = "C:\Program Files\Java\jdk-11.0.x"
$env:ANDROID_SDK_ROOT = "C:\Users\YourUsername\AppData\Local\Android\Sdk"
$env:ANDROID_HOME = $env:ANDROID_SDK_ROOT
$env:PATH += ";$env:ANDROID_SDK_ROOT\platform-tools;$env:ANDROID_SDK_ROOT\tools"
```

#### على macOS/Linux:
```bash
# أضف إلى ~/.bashrc أو ~/.zshrc
export JAVA_HOME=$(/usr/libexec/java_home -v 11)
export ANDROID_SDK_ROOT=$HOME/Library/Android/sdk
export ANDROID_HOME=$ANDROID_SDK_ROOT
export PATH=$PATH:$ANDROID_SDK_ROOT/platform-tools:$ANDROID_SDK_ROOT/tools
```

### 3. استنساخ المشروع وتثبيت الاعتماديات

```bash
# الانتقال إلى مجلد المشروع
cd bank_sms_analyzer

# تثبيت الحزم
npm install

# أو باستخدام pnpm
pnpm install
```

## بناء ملف APK

### الطريقة 1: بناء APK للتطوير (Debug)

```bash
# الانتقال إلى مجلد المشروع
cd bank_sms_analyzer

# بناء APK
eas build --platform android --local

# أو باستخدام Gradle مباشرة
cd android
./gradlew assembleDebug
cd ..
```

سيتم إنشاء ملف APK في:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

### الطريقة 2: بناء APK للإصدار (Release)

```bash
# بناء APK للإصدار
eas build --platform android --local --release

# أو باستخدام Gradle
cd android
./gradlew assembleRelease
cd ..
```

سيتم إنشاء ملف APK في:
```
android/app/build/outputs/apk/release/app-release.apk
```

## تثبيت التطبيق على جهازك

### الطريقة 1: عبر USB

```bash
# تأكد من توصيل جهازك عبر USB وتفعيل وضع التطوير

# تثبيت APK
adb install path/to/app-debug.apk

# أو
adb install-multiple path/to/app-debug.apk
```

### الطريقة 2: نقل الملف يدويًا

1. انسخ ملف APK إلى جهازك عبر USB
2. افتح مدير الملفات على جهازك
3. انقر على ملف APK لتثبيته
4. اتبع التعليمات على الشاشة

## استخدام التطبيق

### الخطوة الأولى: منح الصلاحيات

عند فتح التطبيق لأول مرة، سيطلب منك:
- **صلاحية قراءة الرسائل** (READ_SMS)
- **صلاحية استقبال الرسائل** (RECEIVE_SMS)

اضغط على "السماح" لمنح هذه الصلاحيات.

### الخطوة الثانية: مراقبة الرسائل

بعد منح الصلاحيات، سيبدأ التطبيق بمراقبة الرسائل النصية الواردة تلقائياً. عند استقبال رسالة بنكية:

1. يقوم التطبيق بتحليلها فوراً
2. يستخرج المبلغ والتاجر والفئة
3. يحفظها في قاعدة البيانات المحلية
4. تظهر العملية في قائمة التطبيق

### الخطوة الثالثة: عرض البيانات

- **الشاشة الرئيسية**: تعرض إجمالي المصروفات وقائمة العمليات
- **حالة المراقبة**: تظهر أعلى الشاشة (أخضر = نشطة، أحمر = معطلة)
- **تحديث البيانات**: اسحب لأسفل لتحديث القائمة يدويًا

## استكشاف الأخطاء

### المشكلة: لا تظهر الرسائل في التطبيق

**الحل:**
1. تأكد من منح صلاحيات READ_SMS و RECEIVE_SMS
2. تحقق من أن التطبيق يعمل في الخلفية
3. جرب إرسال رسالة اختبار من بنكك
4. تحقق من سجل التطبيق في الإعدادات

### المشكلة: التطبيق يتعطل عند الفتح

**الحل:**
1. امسح ذاكرة التطبيق من الإعدادات
2. أعد تثبيت التطبيق
3. تأكد من تثبيت جميع الحزم بشكل صحيح

### المشكلة: البيانات لا تُحفظ

**الحل:**
1. تأكد من وجود مساحة تخزين كافية
2. تحقق من صلاحيات الكتابة على التطبيق
3. جرب حذف البيانات وإعادة تثبيت التطبيق

## معلومات تقنية

### المكتبات المستخدمة

| المكتبة | الإصدار | الوظيفة |
|--------|---------|---------|
| React Native | 0.81 | إطار العمل الأساسي |
| Expo | 54 | أدوات التطوير والبناء |
| React Native SQLite Storage | 6.0.1 | قاعدة البيانات المحلية |
| React Native Android SMS Listener | 2.0.0 | استقبال الرسائل |

### هيكل المشروع

```
bank_sms_analyzer/
├── app/                          # شاشات التطبيق
│   └── (tabs)/
│       └── index.tsx            # الشاشة الرئيسية
├── lib/
│   └── services/
│       ├── database.ts          # إدارة قاعدة البيانات
│       ├── sms-analyzer.ts      # تحليل الرسائل
│       └── sms-listener.ts      # استقبال الرسائل
├── android/                      # كود Android الأصلي
│   └── app/src/main/java/
│       └── com/banksmsanalyzer/
│           ├── SmsListenerModule.java
│           └── SmsListenerPackage.java
├── app.config.ts                # إعدادات التطبيق
└── package.json                 # الحزم والاعتماديات
```

## الدعم والمساعدة

إذا واجهت أي مشاكل:

1. تحقق من سجل الأخطاء في وحدة التحكم
2. جرب حذف `node_modules` وإعادة التثبيت
3. تأكد من تحديث جميع الأدوات إلى أحدث إصدار

## الخصوصية والأمان

- جميع البيانات تُحفظ محلياً على جهازك
- لا يتم إرسال أي بيانات إلى خوادم خارجية
- التطبيق يعمل بدون الحاجة لحساب أو تسجيل دخول
- يمكنك حذف البيانات في أي وقت من إعدادات التطبيق

## الترخيص

هذا التطبيق مفتوح المصدر ومتاح للاستخدام الشخصي.

---

**آخر تحديث**: 23 فبراير 2026
